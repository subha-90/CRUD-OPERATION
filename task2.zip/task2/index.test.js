
const request = require('supertest');
const app = require('./server');

describe('CRUD operation', () => {
    test('should return success response', async () => {
        const requestBody = {
            "dob": "1998-07-03",
            "firstName": "drdtyuvy",
            "lastName": "hvjvjyuvjyvj",
            "aadhar": "5446484854515",
            "password": "gcutuyfytfyuf",
            "address": "123 jhyuyfuy yfy",
            "state": "vyhj",
            "city": "hvhjvjhbv",
            "pincode": "765432"
        };

        const authorization = { "mobile": "7987614405" };

        const response = await request(app)
            .post('/api/signup')
            .set('authorization', JSON.stringify(authorization))
            .send(requestBody);

        expect(response.body.status).toBe(0);
    }, 10000);


    test('should return authentication succesfull response', async() =>{
        const requestBody ={
                "mobile":"7987614405",
               "password":"gcutuyfytfyuf"
        };

        const response = await request(app)
        .post('/api/signin')
        .send(requestBody)

        expect(response.body.status).toBe(0)
    },10000);

    test('should return user fetched succesfully response', async()=>{
        const requestBody ={
            "mobile":"7987614405"
        };
        const response = await request(app)
        .get('/api/fetchuser')
        .send(requestBody)

        expect(response.body.status).toBe(0); 
    },10000);

    test('should retun successfully updated response',async()=>{
        const requestBody={"dob":"1998-07-03", 
        "mobile":"7987614405",
         "firstName":"drdtyuvy", 
         "lastName":"hvjvjyuvjyvj", 
         "aadhar":"5446484854515",
        "password":"gcutuyfytfyuf", 
        "confirm_password":"gcutuyfytfyuf",
        "address":"123 jhyuyfuy yfy",
        "state":"vyhj",
        "city":"hvhjvjhbv", 
        "pincode":"765431"
        };

        const response = await request(app)
        .put('/api/updateuser')
        .send(requestBody)

        expect(response.body.status).toBe(0); 
    },10000);

    test('should return successfully deleted response',async() =>{
        const requestBody ={
            "mobile":"7987614405",
            "password":"gcutuyfytfyuf"
        }

        const response = await request(app)
        .delete('/api/deleteuser')
        .send(requestBody)

        expect(response.body.status).toBe(0)
    },10000);
});


