const redis = require('ioredis')

const client = redis.createClient({
    password: '',
    socket: {
        host: 'redis-18613.c1.us-central1-2.gce.cloud.redislabs.com',
        port: 18613
    }
});
client.on('connect',() => console.log('::> Redis client connected'));
client.on('error',(err) => console.log('<:: Redis client err', err));



module.exports = client;