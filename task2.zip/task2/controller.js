
const {validateUserFields, createUser,fetchUser,updateUser,deleteUser }=require('./user.service')
const { authenticateUser } = require('./auth.service');

const signupUser = async (req, res) => {
  try {
    console.log(req.body)
    const validationError = validateUserFields(req.body);

    if (validationError) {
      return res.status(400).json({ error: validationError });
    }

    const newUser = await createUser(req);
    console.log("in new user",newUser)
    return res.status(201).json({status: newUser.status,status_desc: newUser.status_desc});
  } catch (error) {
    console.log(error.message);
    return res.status(500).json({ error:error.message });
  }
};

const signInUser = async (req, res) => {
  try { 

    const loginUser = await authenticateUser(req.body);
    res.status(200).send({status: loginUser.status,status_desc: loginUser.status_desc});
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};



const fetchuser = async (req, res) => {
  try {
    let loginUser =await fetchUser(req.body);
    res.status(200).send({status: loginUser.status , status_desc: loginUser.status_desc});
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};



const updateuser = async (req, res) => {
  try {
     updateResult = await updateUser(req.body);


    res.status(200).send(updateResult);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};





const deleteuser = async (req, res) => {
  try {
    const deleteResult = await deleteUser(req.body.mobile);

    if (!deleteResult.success) {
      return res.status(400).send({status: deleteResult.status , status_desc: deleteResult.status_desc});
    }

    res.status(200).send(deleteResult);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};








module.exports={signupUser,signInUser,fetchuser,updateuser,deleteuser};