const express = require('express');
const router = express.Router();
const { signupUser, signInUser, fetchuser, updateuser, deleteuser } = require('./controller');
const { validateSignupUser } = require('./middlewares/uniqueMobileMiddleware');

router.post('/signup', validateSignupUser, signupUser);


router.post('/signin', signInUser);

router.get('/fetchuser', fetchuser);

router.put('/updateuser', updateuser);

router.delete('/deleteuser', deleteuser);



module.exports = router;