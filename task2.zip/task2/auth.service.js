const crypto = require('crypto');
const userModel = require('./models/User');
const client = require('./redis');
const pool = require('./db');

const hashPassword = (password) => {
  if (password && typeof password === 'string') {
    return crypto.createHash('sha256').update(password).digest('hex');
  } else {
    console.error("Error in hashPassword: Password is undefined or empty");
    return null;
  }
};



const authenticateUser = async (userData) => {
  const searchQuery = 'SELECT * FROM Students WHERE mobile = $1';
  try {
    console.log("Before authentication");
    let mobile = userData.mobile;
    let password = userData.password;
    console.log("Mobile:", mobile);
    console.log("Password:", password);

    if (!mobile) {
      console.log("Authentication failed: Mobile is missing");
      return { status: 1, status_desc: "Mobile is missing" };
    }
    if (!password) {
      console.log("Authentication failed: password is missing");
      return { status: 1, status_desc: "password is missing" };
    }

    // Check user in PostgreSQL
    const loginUserResult = await pool.query(searchQuery, [mobile]);

    if (loginUserResult.rows.length === 0) { 
      console.log("Authentication failed: Mobile number not found");
      return { status: 1, status_desc: "Mobile number not found" };
    }

    const loginUser = loginUserResult.rows[0];

    if (loginUser.password !== password) {
      console.log("Authentication failed: Password doesn't match");
      return { status: 1, status_desc: "Password doesn't match" };
    }

    console.log("Authentication successful");

    // Set data in Redis with expiration
    const redisResponse = await client.hmset(mobile, loginUser);
    await client.expire(mobile, 60);
    console.log("Response from Redis:", redisResponse);
    
    var Response = await client.hgetall(userData.mobile)
    console.log("response from redis", Response)


    return { status: 0, status_desc: "User authenticated successfully" };
  } catch (error) {
    console.error("Error in authentication:", error);
    console.log("Authentication failed: Internal Server Error");
    return { status: 1, status_desc: "Internal Server Error" };
  }
};




 

module.exports = { authenticateUser };
