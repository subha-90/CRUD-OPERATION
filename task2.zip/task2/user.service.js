const crypto = require('crypto');
const User = require('./models/User');
const db = require('./db');
const client = require('./redis');
const pool = require('./db');
const elasticsearch = require("@elastic/elasticsearch");

const Client = new elasticsearch.Client({
  node:  'https://a49e180fb8bd46cc83ce58fc52c87d88.us-central1.gcp.cloud.es.io',
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Authorization': 'ApiKey X2lsOVk0MEJOREhRaEFTUTRFbWI6NnQxZWFmZzNSSXE2SkhsWVMxa0pqQQ==',
  },
})


// module.exports = elasticClient;
const hashPassword = (password) => {
  return crypto.createHash('sha256').update(password).digest('hex');
};

const validateUserFields = (userData) => {
  const { dob, firstName, lastName, aadhar, password, address, state, city, pincode } = userData;



  if (!dob) {
    return ({ status: 1, status_desc: "dob should not be empty" })
  }

  const dobParts = dob.split('/');
  const userBirthDate = new Date(`${dobParts[0]}/${dobParts[1]}/${dobParts[2]}`);
  const currentDate = new Date();
  const age = currentDate.getFullYear() - userBirthDate.getFullYear();

  if (age < 18) {
    return ({ status: 1, status_desc: "User must be at least 18 years old" })
  }

  if (!firstName) {
    return ({ status: 1, status_desc: "firstname should not be empty" })
  }
  if (!lastName) {
    return ({ status: 1, status_desc: "lastname should not be empty" })
  }

  if (!aadhar) {
    return ({ status: 1, status_desc: "adhaar should not be empty" })
  }

  if (!password) {
    return ({ status: 1, status_desc: "password should not be empty" })
  }

  if (!address) {
    return ({ status: 1, status_desc: "adress should not be empty" })
  }

  if (!state) {
    return ({ status: 1, status_desc: "state should not be empty" })
  }

  if (!city) {
    return ({ status: 1, status_desc: "city should not be empty" })
  }

  if (!pincode) {
    return ({ status: 1, status_desc: "pincode should not be empty" })
  }
  return null; // Validation passed
};




const createUser = async (req) => {
  const userData = req.body
  const token = JSON.parse(req.headers.authorization)
  const values2 = token.mobile
  const values = {
     dob : userData.dob,
    mobile : req.mobile,
    firstname : userData.firstName,
    lastName : userData.lastName,
    aadhar : userData.aadhar,
    password : userData.password,
    address : userData.address,
    state : userData.state,
    city : userData.city,
    pincode : userData.pincode
    };

  const searchQuery = `Select * from Students where mobile =$1`
  const query = `
    INSERT INTO students ( dob, mobile, firstName, lastName, aadhar, password, address, state, city, pincode)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING*;
  `;
  try {
    let pgsearchresult = await pool.query(searchQuery,[req.mobile]);
    console.log("pg search result", JSON.stringify(pgsearchresult));
    if (pgsearchresult.rows.length > 0) {
      return ({ status: 1, status_desc: "Mobile number exists" })
    }
    let pginsertresult = await pool.query(query,[values.dob,values.mobile,values.firstname,values.lastName,values.aadhar,values.password,values.address,values.state,values.city,values.pincode]).catch((error) => {
      console.log("pg insert result catch block ", error)
      throw error;
    })
    console.log("pg insert result", JSON.stringify(pginsertresult));


    if (pginsertresult.rowCount == 1) {
      // await Client.index({
      //   index: 'isu',
      //   body: JSON.stringify(values)
      // }).then((elasticresult) => {
      // //  console.log("in elastic",elas)
      //   console.log("sending to elastic", values);
      //   console.log("in elastic reasyult",elasticresult);
      //   console.log({status:0,status_desc:"user created successfully",data:pginsertresult.rows[0]});
      //   return({status:0,status_desc:"user created successfully",data:pginsertresult.rows[0]});
      // }).catch((err) => { 
      //   console.log(`elasticerr in catch block result ${err}`);
      //   throw err;
      // })
     try {
      const response =await Client.index({index:'isu',body:JSON.stringify(values)});
      console.log("in elastic",response);
      if(response !=null){
        return({status:0,status_desc:"user created successfully",data:pginsertresult.rows[0]})
      }
      return ({status:1,status_desc:"user can't be created"})
     } catch (error) {
      console.log("something wrong has happened in elastic search",error.message)
      throw error;
     }
    }

  } catch (error) {
    console.error('Error creating user:', error);
    throw error;
  }

};

function isEmptyObject(obj) {
  return Object.entries(obj).length === 0;
}
const fetchUser = async (data) => {
  const searchQuery = 'SELECT * FROM students WHERE mobile = $1';
  try {
    const mobile = data.mobile;

    const redisData = await client.hgetall(mobile);
    console.log("Redis Data is here", redisData);
    if (isEmptyObject(redisData)) {
      return { status: 1, status_desc: "Need to sign in", data: redisData };
    } else {
      return { status: 0, status_desc: "user fetched Successfully" };
    }
  } catch (error) {
    console.log("Error in fetching user:", error.message);
    return { status: 1, status_desc: "Internal Server Error" };
  }
};



const updateUser = async (userData) => {
  try {
    console.log(userData)
    let mobile = userData.mobile;

    const userExistsResult = await pool.query('SELECT * FROM students WHERE mobile = $1', [mobile]);

    if (userExistsResult.rows.length === 0) {
      return { status: 1, status_desc: 'No such mobile no. found' };
    }

    if (userData.address && userData.address.length > 40) {
      return { status: 1, status_desc: 'Address length cannot be greater than 40' };
    }

    userData.password = hashPassword(userData.password);
    userData.confirm_password = hashPassword(userData.confirm_password);

    if (userData.password !== userData.confirm_password) {
      return { status: 1, status_desc: 'Confirm password did not match' };
    }

    const updateUserResult = await pool.query(`
          UPDATE students
          SET
            firstname = $2,
            lastname = $3,
            dob = $4,
            state = $5,
            city = $6,
            pincode = $7,
            address = $8,
            aadhar = $9,
            password = $10
          WHERE mobile = $1
          RETURNING *;
        `, [
      mobile,
      userData.firstname,
      userData.lastname,
      userData.dob,
      userData.state,
      userData.city,
      userData.pincode,
      userData.address,
      userData.aadhar,
      userData.password
    ]);

    console.log('User update successful');
    return { status: 0, status_desc: 'User updated successfully', data: updateUserResult.rows[0] };
  } catch (error) {
    console.log('User update failed: Internal Server Error', error.message);
    return { status: 1, status_desc: 'Internal Server Error' };
  }
};




const deleteUser = async (mobile) => {
  const client = await pool.connect();

  try {

    const checkUserQuery = 'SELECT * FROM students WHERE mobile = $1';
    const checkUserResult = await client.query(checkUserQuery, [mobile]);

    if (checkUserResult.rows.length === 0) {

      console.log("User deletion failed: No such mobile no. found");
      return { status: 1, status_desc: "No such mobile no. found" };
    }
    const deleteUserQuery = 'DELETE FROM students WHERE mobile = $1 RETURNING *';
    const deleteUserResult = await client.query(deleteUserQuery, [mobile]);

    console.log("User deletion successful");
    return { status: 0, status_desc: "User deleted successfully", data: deleteUserResult.rows };
  } catch (error) {
    console.error("Error in deleting user:", error);
    console.log("User deletion failed: Error in deleting user");
    return { status: 1, status_desc: "Error in deleting user" };
  } finally {
    client.release();
  }
};







module.exports = { validateUserFields, createUser, fetchUser, updateUser, deleteUser };

