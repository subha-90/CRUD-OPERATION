const { Pool } = require('pg');

const pool = new Pool({
  host:"localhost",
  user:"postgres",
  port:5433,
  password:"subha90",
  database:"postgres"
});

pool.connect((err) => {
  if (err) {
    console.error('Error connecting to PostgreSQL:', err);
  } else {
    console.log('Connected to PostgreSQL database');
  }
});

module.exports = pool;

