const jwt = require("jsonwebtoken");

const validateSignupUser = (req, res, next) => {
  try {
    const token = req.headers.authorization;
    console.log(`fetched token from header ----->>>>${token}`);
    let Token = JSON.parse(token)
    console.log(`----fetched token from header--${JSON.stringify(Token)}`);
    if (!Token) {
      console.log("Token Error: No token found");
      return res.status(200).json({ status: 1, status_desc: "No token found" });
    }
    const { mobile } = Token;

    if (!mobile) {
      console.log(`No mobile found in token`);
      return res.status(200).json({ status: 1, status_desc: "No mobile found in token" });
    }

    req.mobile = mobile;
    next();
  } catch (err) {
    console.log(`Token authentication error: ${err}`);
    return res.status(200).json({ status: 1, status_desc: "Token authentication error" });
  }
};

module.exports = {
  validateSignupUser
};
