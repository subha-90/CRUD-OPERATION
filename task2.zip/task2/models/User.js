const pool = require('../db');

const userSchema = `
  CREATE TABLE IF NOT EXISTS students(
    id SERIAL PRIMARY KEY,
    dob DATE,
    mobile VARCHAR(10) UNIQUE,
    firstName VARCHAR(255),
    lastName VARCHAR(255),
    aadhar VARCHAR(255),
    password VARCHAR(255),
    address VARCHAR(255),
    state VARCHAR(255),
    city VARCHAR(255),
    pincode VARCHAR(10)
  );
`

// const createUserTable = async () => {
//   try {
//     const result = await pool.query(userSchema);
//     console.log('User table created successfully:', result);
//   } catch (error) {
//     console.error('Error creating user table:', error);
//   }
// };

//createUserTable();


//module.exports = {createUserTable};